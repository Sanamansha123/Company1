﻿using System.Web.UI;

namespace CompanyWebService.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}